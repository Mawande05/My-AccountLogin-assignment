package com.example.myaccountlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String Username;
    String Password;
    int Phone;

    EditText UsernameInput;
    EditText PasswordInput;
    EditText PhoneInput;
    Button Sign_InButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UsernameInput = (EditText) findViewById(R.id.editText2);
        PasswordInput= (EditText) findViewById(R.id.editText3);
        PhoneInput = (EditText) findViewById(R.id.editText5);
        Sign_InButton =(Button) findViewById(R.id.button);

        Sign_InButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Username = UsernameInput.getText().toString();
                Password = PasswordInput.getText().toString();
                Phone = Integer.valueOf(PhoneInput.getText().toString());

                showToast(Username);
                showToast(Password);
                showToast(String.valueOf(Phone));

            }
        });


    }
    private  void showToast(String text){
        Toast.makeText(MainActivity.this,text,Toast.LENGTH_SHORT).show();

    }

}
